import { Phone, Mail, MapPin, Send } from 'lucide-react';
import { useState, FormEvent } from 'react';
import { useScrollReveal } from '../hooks/useScrollReveal';

export default function Contact() {
  const [form, setForm]         = useState({ name: '', phone: '', project: 'Royal Apartment', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const leftRef  = useScrollReveal();
  const rightRef = useScrollReveal();

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm({ name: '', phone: '', project: 'Royal Apartment', message: '' });
    }, 3500);
  };

  const contactItems = [
    { icon: Phone, label: 'Call Us',           value: '+91 98765 43210',    sub: '+91 98765 43211' },
    { icon: Mail,  label: 'Email Us',           value: 'sales@akhgroup.com', sub: 'info@akhgroup.com' },
    { icon: MapPin, label: 'Corporate Office',  value: 'AKH Tower, Sector 62,', sub: 'Noida, UP, India' },
  ];

  return (
    <section id="contact" className="py-28 bg-[#fdf8f0] relative">
      <div className="warm-divider absolute top-0 inset-x-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="text-xs font-bold tracking-[0.25em] text-[#8B1A1A] uppercase mb-3">Reach Out</p>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#1a0505] mb-4">Get In Touch</h2>
          <div className="red-line w-20 mx-auto rounded-full" />
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl overflow-hidden border border-[#e8d0b8] shadow-[0_8px_40px_rgba(139,26,26,0.08)] flex flex-col lg:flex-row relative">
          {/* Warm glow spots */}
          <div className="absolute top-0 right-0 w-64 h-64 rounded-full pointer-events-none"
            style={{ background: 'radial-gradient(circle, rgba(139,26,26,0.06) 0%, transparent 70%)' }} />
          <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full pointer-events-none"
            style={{ background: 'radial-gradient(circle, rgba(201,148,60,0.06) 0%, transparent 70%)' }} />

          {/* Left — contact info, slides from left */}
          <div ref={leftRef} className="reveal-left p-10 lg:p-14 lg:w-1/2 relative z-10">
            <h3 className="text-3xl font-serif font-bold text-[#1a0505] mb-3">Let's Start a Conversation</h3>
            <p className="text-[#8B6060] font-light mb-10">Schedule a visit or callback from our property advisors.</p>

            <div className="space-y-7">
              {contactItems.map(({ icon: Icon, label, value, sub }) => (
                <div key={label} className="flex items-start gap-5">
                  <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center border border-[#e8d0b8] flex-shrink-0">
                    <Icon className="w-5 h-5 text-[#8B1A1A]" />
                  </div>
                  <div>
                    <div className="text-xs text-[#8B6060] uppercase tracking-wider mb-0.5 font-semibold">{label}</div>
                    <div className="text-base font-bold text-[#1a0505]">{value}</div>
                    <div className="text-sm text-[#8B6060]">{sub}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Hours */}
            <div className="mt-10 p-5 rounded-2xl bg-red-50 border border-[#e8d0b8]">
              <p className="text-[#8B1A1A] text-xs uppercase tracking-widest font-bold mb-2">Working Hours</p>
              <p className="text-[#1a0505] text-sm font-semibold">Mon – Sat: 9 AM – 7 PM</p>
              <p className="text-[#8B6060] text-sm">Sunday: 10 AM – 5 PM</p>
            </div>
          </div>

          {/* Right — form, slides from right */}
          <div ref={rightRef} className="reveal-right p-10 lg:p-14 lg:w-1/2 bg-[#fdf8f0] border-t lg:border-t-0 lg:border-l border-[#e8d0b8] relative z-10">
            {submitted ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-green-50 border border-green-200 flex items-center justify-center mx-auto mb-4">
                    <Send className="w-7 h-7 text-green-600" />
                  </div>
                  <p className="text-[#1a0505] text-xl font-serif font-bold mb-2">Thank You!</p>
                  <p className="text-[#8B6060] text-sm">Our advisor will contact you within 24 hours.</p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                {[
                  { label: 'Full Name *',      type: 'text',   key: 'name',    ph: 'Your full name' },
                  { label: 'Mobile Number *',  type: 'tel',    key: 'phone',   ph: '+91 XXXXX XXXXX' },
                ].map(({ label, type, key, ph }) => (
                  <div key={key}>
                    <label className="block text-xs text-[#8B6060] uppercase tracking-wider mb-2 font-semibold">{label}</label>
                    <input
                      required type={type}
                      value={(form as any)[key]}
                      onChange={e => setForm({ ...form, [key]: e.target.value })}
                      className="w-full bg-white border-2 border-[#e8d0b8] rounded-xl px-4 py-3 text-[#1a0505] focus:outline-none focus:border-[#8B1A1A] transition-colors placeholder:text-[#c8b0a0]"
                      placeholder={ph}
                    />
                  </div>
                ))}
                <div>
                  <label className="block text-xs text-[#8B6060] uppercase tracking-wider mb-2 font-semibold">Project of Interest</label>
                  <select
                    value={form.project}
                    onChange={e => setForm({ ...form, project: e.target.value })}
                    className="w-full bg-white border-2 border-[#e8d0b8] rounded-xl px-4 py-3 text-[#1a0505] focus:outline-none focus:border-[#8B1A1A] transition-colors appearance-none"
                  >
                    <option>Royal Apartment</option>
                    <option>Upwan Residence</option>
                    <option>Parth Square</option>
                    <option>General Inquiry</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-[#8B6060] uppercase tracking-wider mb-2 font-semibold">Message (Optional)</label>
                  <textarea
                    value={form.message}
                    onChange={e => setForm({ ...form, message: e.target.value })}
                    rows={3}
                    className="w-full bg-white border-2 border-[#e8d0b8] rounded-xl px-4 py-3 text-[#1a0505] focus:outline-none focus:border-[#8B1A1A] transition-colors resize-none placeholder:text-[#c8b0a0]"
                    placeholder="Tell us your requirements..."
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-4 text-white text-sm font-bold tracking-widest uppercase rounded-xl flex items-center justify-center gap-2 transition-all duration-300 hover:-translate-y-0.5"
                  style={{ background: 'linear-gradient(135deg, #8B1A1A, #6e1414)', boxShadow: '0 6px 20px rgba(139,26,26,0.3)' }}
                  onMouseEnter={e => (e.currentTarget.style.boxShadow = '0 10px 30px rgba(139,26,26,0.45)')}
                  onMouseLeave={e => (e.currentTarget.style.boxShadow = '0 6px 20px rgba(139,26,26,0.3)')}
                >
                  Submit Details
                  <Send size={16} />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
