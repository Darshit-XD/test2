import { Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import logoImg from "@assets/IMG-20260215-WA0002_white.jpg";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (id: string) => {
    if (id === 'home') window.scrollTo({ top: 0, behavior: 'smooth' });
    else document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsOpen(false);
  };

  const links = [
    { label: 'Home',     id: 'home' },
    { label: 'Projects', id: 'properties' },
    { label: 'About',    id: 'about' },
    { label: 'Contact',  id: 'contact' },
  ];

  return (
    /* Always fully opaque — no transparency at any scroll position */
    <nav
      className="fixed w-full z-50"
      style={{
        background: 'linear-gradient(to right, #ffffff 0%, #ffffff 55%, #fdf8f0 100%)',
        borderBottom: '1px solid #e8d0b8',
        boxShadow: scrolled ? '0 2px 20px rgba(139,26,26,0.12)' : '0 1px 4px rgba(139,26,26,0.06)',
        transition: 'box-shadow 0.3s ease',
      }}
    >
      {/* Top stripe */}
      <div className="h-1 bg-gradient-to-r from-[#8B1A1A] via-[#c9943c] to-[#8B1A1A]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[68px]">

          {/* Logo */}
          <button onClick={() => scrollTo('home')} className="flex items-center gap-3 group">
            <img src={logoImg} alt="AKH GROUP" className="h-11 w-auto block" />
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-serif font-bold text-[#8B1A1A]">AKH</span>
              <span className="text-xl font-serif font-semibold text-[#1a0505] tracking-widest group-hover:text-[#8B1A1A] transition-colors duration-300">GROUP</span>
            </div>
          </button>

          {/* Desktop */}
          <div className="hidden md:flex items-center gap-8">
            {links.map(({ label, id }) => (
              <button
                key={id}
                onClick={() => scrollTo(id)}
                className="text-sm font-semibold tracking-wider text-[#3a1010] hover:text-[#8B1A1A] transition-colors duration-300 uppercase nav-link-effect"
              >
                {label}
              </button>
            ))}
            <button
              onClick={() => scrollTo('contact')}
              className="px-6 py-2.5 bg-[#8B1A1A] hover:bg-[#6e1414] text-white text-sm font-bold tracking-wider uppercase rounded-lg transition-all duration-300 hover:-translate-y-0.5"
              style={{ boxShadow: '0 4px 14px rgba(139,26,26,0.3)' }}
            >
              Enquire Now
            </button>
          </div>

          {/* Mobile */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-[#8B1A1A] transition-colors p-1"
          >
            {isOpen ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {isOpen && (
        <div className="md:hidden bg-[#fdf8f0] border-t border-[#e8d0b8]" style={{ boxShadow: '0 8px 20px rgba(139,26,26,0.1)' }}>
          <div className="px-4 pt-2 pb-5 space-y-1">
            {links.map(({ label, id }) => (
              <button
                key={id}
                onClick={() => scrollTo(id)}
                className="block w-full text-left px-4 py-3.5 text-sm font-bold tracking-wider text-[#3a1010] hover:text-[#8B1A1A] hover:bg-red-50 uppercase border-b border-[#f0e0d0] transition-colors"
              >
                {label}
              </button>
            ))}
            <div className="pt-4">
              <button
                onClick={() => scrollTo('contact')}
                className="w-full py-3.5 bg-[#8B1A1A] text-white text-sm font-bold tracking-widest uppercase rounded-lg"
              >
                Enquire Now
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
