import { Award, Users, Building, Star } from 'lucide-react';
import { useScrollReveal } from '../hooks/useScrollReveal';

const stats = [
  { icon: Award,    value: '15+',     label: 'Years Experience' },
  { icon: Users,    value: '5000+',   label: 'Happy Families' },
  { icon: Building, value: '10+',     label: 'Luxury Projects' },
  { icon: Star,     value: 'Premium', label: 'Build Quality' },
];

export default function About() {
  const textRef  = useScrollReveal();
  const imageRef = useScrollReveal();

  return (
    <section id="about" className="py-28 relative overflow-hidden" style={{ background: '#f5ede0' }}>
      {/* Decorative warm blob */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full pointer-events-none opacity-40"
        style={{ background: 'radial-gradient(circle, rgba(201,148,60,0.15) 0%, transparent 70%)', transform: 'translate(30%, -30%)' }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

          {/* Text side — slides from left */}
          <div ref={textRef} className="reveal-left">
            <p className="text-xs font-bold tracking-[0.25em] text-[#c9943c] uppercase mb-4">The Legacy</p>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#1a0505] mb-6 leading-tight">
              Building Dreams <br />For Over A Decade
            </h2>
            <p className="text-[#5c2020] font-light leading-relaxed text-lg mb-4">
              AKH Group has established itself as a premier real estate developer in India, synonymous with trust, quality, and architectural brilliance.
            </p>
            <p className="text-[#8B6060] font-light leading-relaxed">
              We craft lifestyles that resonate with elegance and comfort — delivering landmark projects like Royal Apartment, Upwan Residence, and Parth Square across Noida.
            </p>

            {/* Stats grid */}
            <div className="grid grid-cols-2 gap-5 mt-10">
              {stats.map(({ icon: Icon, value, label }, i) => (
                <div
                  key={label}
                  className="p-6 rounded-2xl bg-white border border-[#e8d0b8] cursor-default group transition-all duration-300 hover:border-[#8B1A1A]/30 hover:shadow-[0_8px_30px_rgba(139,26,26,0.08)]"
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <Icon className="w-10 h-10 text-[#c9943c] mb-3 group-hover:scale-110 transition-transform duration-300" />
                  <div className="text-3xl font-serif font-bold text-[#1a0505] mb-1">{value}</div>
                  <div className="text-xs text-[#8B6060] uppercase tracking-wider font-semibold">{label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Image side — slides from right */}
          <div ref={imageRef} className="reveal-right relative">
            {/* Decorative border offset */}
            <div className="absolute inset-0 border-2 border-[#c9943c]/30 rounded-3xl translate-x-5 translate-y-5" />
            <img
              src="https://images.pexels.com/photos/380769/pexels-photo-380769.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="AKH Group"
              className="relative z-10 rounded-3xl shadow-[0_20px_60px_rgba(139,26,26,0.15)] w-full h-auto object-cover aspect-[4/5]"
            />
            {/* Quote card */}
            <div className="absolute -bottom-8 -left-6 z-20 bg-white p-5 rounded-2xl border border-[#e8d0b8] shadow-[0_8px_30px_rgba(139,26,26,0.12)] max-w-xs">
              <div className="text-[#8B1A1A] font-serif italic text-lg mb-2">
                "Excellence in every square foot."
              </div>
              <div className="text-xs text-[#8B6060] uppercase tracking-widest font-semibold">— AKH Leadership</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
