import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import logoImg from "@assets/IMG-20260215-WA0002_white.jpg";
import { useScrollReveal } from '../hooks/useScrollReveal';

export default function Footer() {
  const footerRef = useScrollReveal();

  const scrollTo = (id: string) => {
    if (id === 'home') window.scrollTo({ top: 0, behavior: 'smooth' });
    else document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const quickLinks = [
    { label: 'Home',         id: 'home' },
    { label: 'Our Projects', id: 'properties' },
    { label: 'About Us',     id: 'about' },
    { label: 'Contact',      id: 'contact' },
  ];
  const projects = ['Royal Apartment', 'Upwan Residence', 'Parth Square'];
  const socials  = [
    { icon: Facebook,  href: 'https://www.facebook.com/akhdeveloper/' },
    { icon: Twitter,   href: '#' },
    { icon: Instagram, href: '#' },
    { icon: Linkedin,  href: '#' },
  ];

  return (
    <footer className="bg-white" style={{ borderTop: '4px solid #8B1A1A' }}>
      {/* Red-gold top stripe */}
      <div className="h-1 bg-gradient-to-r from-[#8B1A1A] via-[#c9943c] to-[#8B1A1A]" />

      <div ref={footerRef} className="reveal-up max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-14">

          {/* Brand — logo blends on white */}
          <div>
            <button onClick={() => scrollTo('home')} className="flex items-center gap-3 mb-5 group">
              <img src={logoImg} alt="AKH GROUP" className="h-13 w-auto block" style={{ height: '52px' }} />
              <div>
                <span className="text-xl font-serif font-bold text-[#8B1A1A]">AKH</span>
                <span className="text-xl font-serif font-semibold text-[#1a0505] ml-1.5 tracking-widest group-hover:text-[#8B1A1A] transition-colors duration-300">GROUP</span>
              </div>
            </button>
            <p className="text-[#8B6060] text-sm leading-relaxed mb-6">
              Shaping the skyline of Noida with unparalleled luxury and uncompromising quality. Since 2009.
            </p>
            <div className="flex gap-3">
              {socials.map(({ icon: Icon, href }, idx) => (
                <a key={idx} href={href} target="_blank" rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-red-50 border border-[#e8d0b8] flex items-center justify-center text-[#8B6060] hover:text-white hover:bg-[#8B1A1A] hover:border-[#8B1A1A] transition-all duration-300">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="text-[#1a0505] font-bold text-sm uppercase tracking-widest mb-2 pb-2 border-b-2 border-[#8B1A1A] inline-block">Quick Links</h4>
            <ul className="space-y-3 mt-4">
              {quickLinks.map(({ label, id }) => (
                <li key={id}>
                  <button onClick={() => scrollTo(id)}
                    className="text-[#8B6060] hover:text-[#8B1A1A] text-sm transition-colors duration-200 flex items-center gap-2 group">
                    <span className="w-0 group-hover:w-3 h-0.5 bg-[#8B1A1A] transition-all duration-300 inline-block rounded-full" />
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Projects */}
          <div>
            <h4 className="text-[#1a0505] font-bold text-sm uppercase tracking-widest mb-2 pb-2 border-b-2 border-[#8B1A1A] inline-block">Projects</h4>
            <ul className="space-y-3 mt-4">
              {projects.map((p) => (
                <li key={p}>
                  <button onClick={() => scrollTo('properties')}
                    className="text-[#8B6060] hover:text-[#8B1A1A] text-sm transition-colors duration-200 flex items-center gap-2 group">
                    <span className="w-0 group-hover:w-3 h-0.5 bg-[#8B1A1A] transition-all duration-300 inline-block rounded-full" />
                    {p}
                  </button>
                </li>
              ))}
            </ul>

            {/* RERA badge */}
            <div className="mt-8 bg-red-50 border-2 border-[#8B1A1A]/20 rounded-2xl p-4 inline-flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-[#8B1A1A] rounded-full flex items-center justify-center mb-2">
                <span className="text-white font-bold text-xs">RERA</span>
              </div>
              <p className="text-[#1a0505] text-xs font-bold">UP RERA Registered</p>
              <p className="text-[#8B6060] text-xs mt-0.5">Reg No: UPRERAPRJ12345</p>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-[#1a0505] font-bold text-sm uppercase tracking-widest mb-2 pb-2 border-b-2 border-[#8B1A1A] inline-block">Contact</h4>
            <ul className="space-y-5 mt-4">
              {[
                { icon: MapPin, text: 'Sector 62, Noida, Uttar Pradesh — 201301' },
                { icon: Phone,  text: '+91 98765 43210' },
                { icon: Mail,   text: 'sales@akhgroup.com' },
              ].map(({ icon: Icon, text }) => (
                <li key={text} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-red-50 border border-[#e8d0b8] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Icon size={14} className="text-[#8B1A1A]" />
                  </div>
                  <span className="text-[#8B6060] text-sm">{text}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-[#f0e0d0] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[#c8b0a0] text-sm">
            &copy; {new Date().getFullYear()} AKH Group. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-[#c8b0a0] hover:text-[#8B1A1A] transition-colors">Privacy Policy</a>
            <a href="#" className="text-[#c8b0a0] hover:text-[#8B1A1A] transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
