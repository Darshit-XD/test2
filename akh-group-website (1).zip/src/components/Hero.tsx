import { ChevronRight, Star, MapPin } from 'lucide-react';

export default function Hero() {
  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section id="home" className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">

      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 z-10"
          style={{ background: 'linear-gradient(to bottom, rgba(26,5,5,0.75) 0%, rgba(26,5,5,0.55) 50%, rgba(26,5,5,0.85) 100%)' }} />
        <img
          src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Luxury Real Estate"
          className="w-full h-full object-cover object-center"
          style={{ animation: 'kenburns 22s ease-in-out infinite alternate' }}
        />
      </div>

      {/* Warm glow overlays */}
      <div className="absolute top-1/3 left-1/4 w-[500px] h-[500px] rounded-full pointer-events-none z-10"
        style={{ background: 'radial-gradient(circle, rgba(139,26,26,0.12) 0%, transparent 70%)' }} />

      {/* ── Hero Content — pushed up so CTA buttons are above scroll indicator ── */}
      <div className="relative z-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center -mt-16">

        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full mb-8"
          style={{ background: 'rgba(201,148,60,0.15)', border: '1px solid rgba(201,148,60,0.4)', backdropFilter: 'blur(8px)' }}>
          <Star className="w-3.5 h-3.5 text-[#c9943c]" fill="#c9943c" />
          <span className="text-xs font-semibold tracking-[0.3em] text-[#c9943c] uppercase">Premium Indian Real Estate</span>
          <MapPin className="w-3.5 h-3.5 text-[#c9943c]" />
          <span className="text-xs text-[#c9943c]/80">Noida</span>
        </div>

        {/* Heading */}
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-white leading-[1.08] mb-6 drop-shadow-2xl">
          Experience{' '}
          <span className="gold-shimmer-text">Luxury</span>
          <br />Redefined.
        </h1>

        <p className="text-lg md:text-xl text-white/75 max-w-xl mx-auto font-light leading-relaxed mb-10">
          Crafting architectural masterpieces that blend elegance with comfort in the heart of Noida.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={() => scrollTo('properties')}
            className="group px-9 py-4 text-white text-sm font-bold tracking-widest uppercase rounded-lg flex items-center gap-2.5 transition-all duration-300 hover:-translate-y-0.5"
            style={{ background: 'linear-gradient(135deg, #8B1A1A, #6e1414)', boxShadow: '0 6px 24px rgba(139,26,26,0.5)' }}
          >
            Explore Projects
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
          </button>
          <button
            onClick={() => scrollTo('contact')}
            className="px-9 py-4 text-white text-sm font-bold tracking-widest uppercase rounded-lg transition-all duration-300 hover:-translate-y-0.5"
            style={{ border: '1.5px solid rgba(255,255,255,0.4)', backdropFilter: 'blur(8px)', background: 'rgba(255,255,255,0.08)' }}
            onMouseEnter={e => (e.currentTarget.style.background = 'rgba(201,148,60,0.2)')}
            onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.08)')}
          >
            Contact Sales
          </button>
        </div>
      </div>

      {/* ── Scroll indicator — perfectly centered ── */}
      <div
        className="scroll-mouse absolute bottom-12 z-20 flex flex-col items-center gap-2"
        style={{ left: '50%', transform: 'translateX(-50%)', animation: 'floatBounce 2s ease-in-out infinite' }}
      >
        <span className="text-[10px] font-semibold tracking-[0.3em] uppercase text-[#c9943c]/80">Scroll</span>
        <div className="w-7 h-11 rounded-full flex items-start justify-center pt-2"
          style={{ border: '2px solid rgba(201,148,60,0.5)' }}>
          <div
            className="w-1.5 h-2.5 bg-[#c9943c] rounded-full scroll-mouse-dot"
          />
        </div>
      </div>

      <style>{`
        @keyframes kenburns {
          from { transform: scale(1.04) translateX(0px); }
          to   { transform: scale(1.13) translateX(-24px); }
        }
      `}</style>
    </section>
  );
}
