import { MapPin, Bed, Bath, Square, Heart, ChevronLeft, Star } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import PropertyDetails from './PropertyDetails';
import { useScrollReveal } from '../hooks/useScrollReveal';
import royalLogo from "@assets/IMG-20260215-WA0013_1771173295946.jpg";
import parthLogo from "@assets/IMG-20260215-WA0012_1771173308132.jpg";
import upwanLogo from "@assets/IMG-20260215-WA0001_1771173452705.jpg";

export interface Property {
  id: number; title: string; location: string; price: string;
  beds: number; baths: number; area: string; image: string;
  features?: string[]; projectLogo?: string; subProperties?: Property[];
}

const properties: Property[] = [
  {
    id: 1, title: 'Royal Apartment', location: 'Premium Sector, Noida',
    price: 'Starting ₹85 L*', beds: 3, baths: 3, area: '1,850',
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
    projectLogo: royalLogo, features: ['3 & 4 BHK', 'Club House', 'Smart Home'],
    subProperties: [
      { id: 101, title: 'Royal 3BHK Elite', location: 'Wing A', price: '₹85 L', beds: 3, baths: 3, area: '1850', image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800' },
      { id: 102, title: 'Royal 4BHK Grand', location: 'Wing B', price: '₹1.2 Cr', beds: 4, baths: 4, area: '2400', image: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800' },
    ],
  },
  {
    id: 2, title: 'Upwan Residence', location: 'Green Valley, Noida Extension',
    price: 'Starting ₹65 L*', beds: 2, baths: 2, area: '1,250',
    image: 'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=800',
    projectLogo: upwanLogo, features: ['2 & 3 BHK', 'Park Facing', 'Gymnasium'],
    subProperties: [
      { id: 201, title: 'Upwan 2BHK Classic', location: 'Block 1', price: '₹65 L', beds: 2, baths: 2, area: '1250', image: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=800' },
      { id: 202, title: 'Upwan 3BHK Premium', location: 'Block 2', price: '₹82 L', beds: 3, baths: 3, area: '1600', image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800' },
    ],
  },
  {
    id: 3, title: 'Parth Square', location: 'Noida Phase-II',
    price: 'Starting ₹55 L*', beds: 2, baths: 2, area: '1,100',
    image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    projectLogo: parthLogo, features: ['2 BHK', 'Retail Shops', 'Connectivity'],
    subProperties: [
      { id: 301, title: 'Parth Studio', location: 'Tower A', price: '₹55 L', beds: 1, baths: 1, area: '800', image: 'https://images.pexels.com/photos/439391/pexels-photo-439391.jpeg?auto=compress&cs=tinysrgb&w=800' },
      { id: 302, title: 'Parth 2BHK', location: 'Tower B', price: '₹72 L', beds: 2, baths: 2, area: '1100', image: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=800' },
    ],
  },
];

/* Building silhouette SVG — decorates the sides of the section */
function BuildingSilhouette({ side }: { side: 'left' | 'right' }) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.2 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div
      ref={sectionRef}
      className="absolute top-0 bottom-0 w-16 md:w-24 pointer-events-none overflow-hidden"
      style={{ [side]: 0 }}
    >
      {/* Tall center tower */}
      <div
        className="absolute bottom-0 w-10 md:w-14"
        style={{
          [side]: '50%',
          height: '65%',
          background: 'linear-gradient(to top, rgba(139,26,26,0.10), rgba(139,26,26,0.04))',
          borderTop: '2px solid rgba(139,26,26,0.12)',
          borderLeft: side === 'left' ? 'none' : '1px solid rgba(139,26,26,0.08)',
          borderRight: side === 'right' ? 'none' : '1px solid rgba(139,26,26,0.08)',
          transition: 'transform 1.2s cubic-bezier(0.22,0.61,0.36,1), opacity 1.2s ease',
          transform: visible
            ? `translateX(${side === 'left' ? '-50%' : '50%'}) translateY(0)`
            : `translateX(${side === 'left' ? '-50%' : '50%'}) translateY(100%)`,
          opacity: visible ? 1 : 0,
        }}
      >
        {/* Windows grid */}
        {[...Array(8)].map((_, row) => (
          <div key={row} className="flex justify-around px-1.5 mt-2">
            {[...Array(2)].map((_, col) => (
              <div
                key={col}
                className="w-1.5 h-2 rounded-sm"
                style={{
                  background: (row + col) % 3 === 0 ? 'rgba(201,148,60,0.5)' : 'rgba(139,26,26,0.15)',
                  transition: `opacity 0.3s ease ${(row * 2 + col) * 80}ms`,
                  opacity: visible ? 1 : 0,
                }}
              />
            ))}
          </div>
        ))}
      </div>

      {/* Short side building */}
      <div
        className="absolute bottom-0 w-8 md:w-10"
        style={{
          [side]: 0,
          height: '40%',
          background: 'linear-gradient(to top, rgba(201,148,60,0.08), rgba(201,148,60,0.02))',
          borderTop: '2px solid rgba(201,148,60,0.15)',
          transition: 'transform 1.4s cubic-bezier(0.22,0.61,0.36,1) 0.2s, opacity 1.4s ease 0.2s',
          transform: visible ? 'translateY(0)' : 'translateY(100%)',
          opacity: visible ? 1 : 0,
        }}
      />
    </div>
  );
}

/* Single card — always visible, entrance animation via CSS */
function PropertyCard({
  property,
  index,
  viewMode,
  isFav,
  onFav,
  onAction,
}: {
  property: Property;
  index: number;
  viewMode: 'projects' | 'units';
  isFav: boolean;
  onFav: () => void;
  onAction: () => void;
}) {
  return (
    <div
      className="bg-white rounded-3xl overflow-hidden border border-[#e8d0b8] card-enter group"
      style={{
        animationDelay: `${index * 120}ms`,
        boxShadow: '0 4px 20px rgba(139,26,26,0.07)',
      }}
    >
      {/* Image */}
      <div className="relative h-60 overflow-hidden">
        <div className="absolute inset-0 z-10"
          style={{ background: 'linear-gradient(to top, rgba(26,5,5,0.65) 0%, transparent 55%)' }} />
        <img
          src={property.image}
          alt={property.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />

        {property.projectLogo && viewMode === 'projects' && (
          <div className="absolute top-4 left-4 z-20 bg-white rounded-xl p-1.5 shadow-md border border-[#e8d0b8]">
            <img src={property.projectLogo} alt="Logo" className="h-9 w-auto object-contain" />
          </div>
        )}

        <button
          onClick={onFav}
          className="absolute top-4 right-4 z-20 bg-white/80 backdrop-blur-sm p-2.5 rounded-full hover:bg-[#8B1A1A] transition-all duration-300 group/fav"
        >
          <Heart size={17} className={isFav
            ? 'fill-[#8B1A1A] text-[#8B1A1A] group-hover/fav:fill-white group-hover/fav:text-white'
            : 'text-[#8B1A1A] group-hover/fav:text-white'}
          />
        </button>

        <div className="absolute bottom-4 left-4 z-20 bg-[#8B1A1A] px-3 py-1.5 rounded-lg">
          <span className="text-sm font-bold text-white">{property.price}</span>
        </div>
      </div>

      {/* Body */}
      <div className="p-6">
        <h3 className="text-xl font-serif font-bold text-[#1a0505] mb-1 group-hover:text-[#8B1A1A] transition-colors">
          {property.title}
        </h3>
        <div className="flex items-center gap-1.5 text-[#8B6060] mb-4 text-sm">
          <MapPin size={13} className="text-[#8B1A1A] flex-shrink-0" />
          <span>{property.location}</span>
        </div>

        {viewMode === 'projects' && property.features && (
          <div className="space-y-2 mb-4">
            {property.features.map((f, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-[#5c2020]">
                <div className="w-1.5 h-1.5 rounded-full bg-[#c9943c] flex-shrink-0" />
                {f}
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-3 gap-3 py-4 border-t border-[#f0e0d0]">
          <div className="flex items-center gap-1.5 text-[#5c2020]">
            <Bed size={15} className="text-[#c9943c]" />
            <span className="text-sm font-semibold">{property.beds}</span>
          </div>
          <div className="flex items-center gap-1.5 text-[#5c2020]">
            <Bath size={15} className="text-[#c9943c]" />
            <span className="text-sm font-semibold">{property.baths}</span>
          </div>
          <div className="flex items-center gap-1.5 text-[#5c2020]">
            <Square size={15} className="text-[#c9943c]" />
            <span className="text-xs font-semibold">{property.area}ft²</span>
          </div>
        </div>

        <button
          onClick={onAction}
          className="w-full mt-4 py-3 border-2 border-[#8B1A1A] text-[#8B1A1A] hover:bg-[#8B1A1A] hover:text-white text-sm font-bold tracking-wider uppercase rounded-2xl transition-all duration-300"
        >
          {viewMode === 'projects' ? 'View Units' : 'View Details'}
        </button>
      </div>
    </div>
  );
}

export default function Properties() {
  const [favorites, setFavorites]               = useState<number[]>([]);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [viewMode, setViewMode]                 = useState<'projects' | 'units'>('projects');
  const [currentProject, setCurrentProject]     = useState<Property | null>(null);
  /* animKey changes on every view switch so cards re-mount and re-animate */
  const [animKey, setAnimKey]                   = useState(0);

  const headingRef = useScrollReveal();
  const trustRef   = useScrollReveal();

  const toggleFav = (id: number) =>
    setFavorites(p => p.includes(id) ? p.filter(f => f !== id) : [...p, id]);

  const openProject = (p: Property) => {
    setCurrentProject(p);
    setViewMode('units');
    setAnimKey(k => k + 1);
    setTimeout(() =>
      document.getElementById('properties')?.scrollIntoView({ behavior: 'smooth' }), 50);
  };

  const goBack = () => {
    setViewMode('projects');
    setAnimKey(k => k + 1);
    setTimeout(() =>
      document.getElementById('properties')?.scrollIntoView({ behavior: 'smooth' }), 50);
  };

  const activeList = viewMode === 'projects' ? properties : (currentProject?.subProperties ?? []);

  return (
    <section id="properties" className="py-28 bg-[#fdf8f0] relative overflow-hidden">
      <div className="warm-divider absolute top-0 inset-x-0" />

      {/* Scroll-in building silhouettes on both sides */}
      <BuildingSilhouette side="left" />
      <BuildingSilhouette side="right" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

        {/* Section header */}
        <div ref={headingRef} className="reveal-up text-center mb-16">
          <p className="text-xs font-bold tracking-[0.25em] text-[#8B1A1A] uppercase mb-3">
            {viewMode === 'projects' ? 'Our Portfolio' : currentProject?.title}
          </p>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#1a0505] mb-5">
            {viewMode === 'projects' ? 'Signature Projects' : 'Available Units'}
          </h2>
          <div className="red-line w-20 mx-auto rounded-full mb-8" />

          {viewMode === 'units' && (
            <button
              onClick={goBack}
              className="inline-flex items-center gap-2 px-6 py-2.5 border-2 border-[#8B1A1A] text-[#8B1A1A] hover:bg-[#8B1A1A] hover:text-white text-sm font-bold tracking-wider uppercase rounded-full transition-all duration-300 group"
            >
              <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              Back to Projects
            </button>
          )}
        </div>

        {/* Cards grid — key changes on view switch, triggering fresh animation */}
        <div
          key={`grid-${animKey}`}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {activeList.map((property, index) => (
            <PropertyCard
              key={property.id}
              property={property}
              index={index}
              viewMode={viewMode}
              isFav={favorites.includes(property.id)}
              onFav={() => toggleFav(property.id)}
              onAction={() =>
                viewMode === 'projects' ? openProject(property) : setSelectedProperty(property)
              }
            />
          ))}
        </div>

        {/* Trust bar */}
        {viewMode === 'projects' && (
          <div ref={trustRef} className="reveal-up mt-16 text-center">
            <div className="inline-flex flex-wrap justify-center items-center gap-3 px-8 py-4 rounded-2xl bg-white border border-[#e8d0b8] shadow-sm">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={15} className="text-[#c9943c]" fill="#c9943c" />
              ))}
              <span className="text-[#5c2020] text-sm ml-1">Trusted by <strong>5000+</strong> happy families across Noida</span>
            </div>
          </div>
        )}
      </div>

      {selectedProperty && (
        <PropertyDetails property={selectedProperty} onClose={() => setSelectedProperty(null)} />
      )}
    </section>
  );
}
