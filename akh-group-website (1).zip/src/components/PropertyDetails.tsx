import { X, MapPin, Bed, Bath, Square, Home, Wifi, Zap, Droplets, TreePine, Phone, Mail, Calendar } from 'lucide-react';
import { useState, FormEvent } from 'react';

interface Property {
  id: number; title: string; location: string; price: string;
  beds: number; baths: number; area: string; image: string;
}
interface Props { property: Property; onClose: () => void; }

const amenities = [
  { icon: Home,     label: 'Modern Design' },
  { icon: Wifi,     label: 'Smart Home' },
  { icon: Zap,      label: 'Solar Power' },
  { icon: Droplets, label: 'Water Feature' },
  { icon: TreePine, label: 'Garden' },
  { icon: Calendar, label: 'Recently Built' },
];

export default function PropertyDetails({ property, onClose }: Props) {
  const [form, setForm]         = useState({ name: '', email: '', phone: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const images = [
    property.image,
    'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/1142681/pexels-photo-1142681.jpeg?auto=compress&cs=tinysrgb&w=800',
  ];
  const [mainImg, setMainImg] = useState(images[0]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => { setSubmitted(false); setForm({ name: '', email: '', phone: '', message: '' }); }, 3000);
  };

  return (
    <div className="fixed inset-0 bg-[#1a0505]/80 backdrop-blur-md z-50 overflow-y-auto">
      {/* Close */}
      <button
        onClick={onClose}
        className="fixed top-5 right-5 z-[60] bg-[#8B1A1A] hover:bg-[#6e1414] text-white p-3 rounded-full transition-all duration-300 shadow-lg hover:-translate-y-0.5"
      >
        <X size={22} />
      </button>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="bg-[#fdf8f0] border border-[#e8d0b8] rounded-3xl overflow-hidden shadow-2xl">

          {/* Gallery + Quick Info */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-8">
            {/* Gallery */}
            <div className="lg:col-span-2 space-y-4">
              <div className="relative overflow-hidden rounded-2xl h-[420px] bg-[#f5ede0] group">
                <img src={mainImg} alt={property.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute bottom-5 left-5 bg-[#8B1A1A] px-4 py-2 rounded-xl">
                  <span className="text-lg font-bold text-white">{property.price}</span>
                </div>
              </div>
              <div className="flex gap-3">
                {images.map((img, i) => (
                  <button key={i} onClick={() => setMainImg(img)}
                    className={`w-24 h-20 rounded-xl overflow-hidden border-2 transition-all duration-300 ${mainImg === img ? 'border-[#8B1A1A] scale-105' : 'border-[#e8d0b8] hover:border-[#c9943c]'}`}>
                    <img src={img} alt={`View ${i + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Quick info */}
            <div className="space-y-5">
              <div>
                <h1 className="text-3xl font-serif font-bold text-[#1a0505] mb-3">{property.title}</h1>
                <div className="flex items-center gap-2 text-sm bg-white px-4 py-3 rounded-xl border border-[#e8d0b8]">
                  <MapPin size={15} className="text-[#8B1A1A]" />
                  <span className="text-[#5c2020]">{property.location}</span>
                </div>
              </div>

              {[
                { icon: Bed,    label: 'Bedrooms',  value: property.beds },
                { icon: Bath,   label: 'Bathrooms', value: property.baths },
                { icon: Square, label: 'Total Area', value: `${property.area} sq ft` },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="bg-white px-4 py-3 rounded-xl border border-[#e8d0b8] flex items-center gap-4">
                  <Icon className="text-[#c9943c]" size={21} />
                  <div>
                    <div className="text-xs text-[#8B6060] uppercase tracking-wider font-semibold">{label}</div>
                    <div className="text-[#1a0505] font-bold">{value}</div>
                  </div>
                </div>
              ))}

              <div className="bg-white p-4 rounded-xl border border-[#e8d0b8] space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-[#8B6060] text-sm font-semibold">Reference ID</span>
                  <span className="text-[#1a0505] font-bold text-sm">AKH-{String(property.id).padStart(5, '0')}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#8B6060] text-sm font-semibold">Availability</span>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-green-50 text-green-700 border border-green-200">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500" />Active Listing
                  </span>
                </div>
              </div>

              <button
                onClick={() => document.getElementById(`cf-${property.id}`)?.scrollIntoView({ behavior: 'smooth' })}
                className="w-full py-4 text-white font-bold text-sm tracking-widest uppercase rounded-xl transition-all duration-300 hover:-translate-y-0.5"
                style={{ background: 'linear-gradient(135deg, #8B1A1A, #6e1414)', boxShadow: '0 6px 20px rgba(139,26,26,0.3)' }}
              >
                Schedule Site Visit
              </button>
            </div>
          </div>

          {/* Overview */}
          <div className="px-8 py-8 border-t border-[#e8d0b8] bg-white">
            <h2 className="text-2xl font-serif font-bold text-[#1a0505] mb-4">Property Overview</h2>
            <p className="text-[#5c2020] leading-relaxed">
              This stunning {property.title.toLowerCase()} is perfectly situated in {property.location}. Featuring {property.beds} spacious bedrooms and {property.baths} luxurious bathrooms across {property.area} sq ft of elegantly designed living space with premium finishes.
            </p>
          </div>

          {/* Amenities */}
          <div className="px-8 py-8 border-t border-[#e8d0b8]">
            <h2 className="text-2xl font-serif font-bold text-[#1a0505] mb-6">Premium Amenities</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {amenities.map(({ icon: Icon, label }) => (
                <div key={label} className="bg-white p-5 rounded-2xl border border-[#e8d0b8] flex items-center gap-3 hover:border-[#8B1A1A]/30 hover:shadow-md transition-all duration-300 group">
                  <div className="bg-red-50 p-2.5 rounded-xl group-hover:bg-[#8B1A1A]/10 transition-colors">
                    <Icon className="text-[#8B1A1A]" size={19} />
                  </div>
                  <span className="text-[#1a0505] font-semibold text-sm">{label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Contact form */}
          <div id={`cf-${property.id}`} className="px-8 py-10 border-t border-[#e8d0b8] bg-[#fdf8f0]">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-2xl font-serif font-bold text-[#1a0505] mb-2 text-center">Express Your Interest</h2>
              <p className="text-[#8B6060] text-center text-sm mb-8">Our property expert will get back to you within 24 hours.</p>

              {submitted ? (
                <div className="bg-green-50 border border-green-200 text-green-700 px-8 py-5 rounded-2xl text-center font-bold">
                  Thank you! Our relationship manager will contact you shortly.
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs text-[#8B6060] uppercase tracking-wider mb-2 font-semibold">Full Name</label>
                      <input required type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                        className="w-full bg-white border-2 border-[#e8d0b8] rounded-xl px-4 py-3 text-[#1a0505] focus:outline-none focus:border-[#8B1A1A] transition-colors placeholder:text-[#c8b0a0]"
                        placeholder="Your name" />
                    </div>
                    <div>
                      <label className="block text-xs text-[#8B6060] uppercase tracking-wider mb-2 font-semibold">Email</label>
                      <input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
                        className="w-full bg-white border-2 border-[#e8d0b8] rounded-xl px-4 py-3 text-[#1a0505] focus:outline-none focus:border-[#8B1A1A] transition-colors placeholder:text-[#c8b0a0]"
                        placeholder="your@email.com" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs text-[#8B6060] uppercase tracking-wider mb-2 font-semibold">Mobile Number</label>
                    <input required type="tel" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}
                      className="w-full bg-white border-2 border-[#e8d0b8] rounded-xl px-4 py-3 text-[#1a0505] focus:outline-none focus:border-[#8B1A1A] transition-colors placeholder:text-[#c8b0a0]"
                      placeholder="+91 XXXXX XXXXX" />
                  </div>
                  <div>
                    <label className="block text-xs text-[#8B6060] uppercase tracking-wider mb-2 font-semibold">Message</label>
                    <textarea required value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} rows={3}
                      className="w-full bg-white border-2 border-[#e8d0b8] rounded-xl px-4 py-3 text-[#1a0505] focus:outline-none focus:border-[#8B1A1A] transition-colors resize-none placeholder:text-[#c8b0a0]"
                      placeholder="I am interested in this property..." />
                  </div>
                  <div className="flex gap-4">
                    <button type="submit"
                      className="flex-1 py-4 text-white font-bold text-sm tracking-widest uppercase rounded-xl transition-all duration-300 hover:-translate-y-0.5"
                      style={{ background: 'linear-gradient(135deg, #8B1A1A, #6e1414)', boxShadow: '0 6px 20px rgba(139,26,26,0.3)' }}>
                      Confirm Interest
                    </button>
                    <button type="button" onClick={onClose}
                      className="flex-1 py-4 border-2 border-[#e8d0b8] hover:border-[#8B1A1A] text-[#1a0505] font-bold text-sm tracking-widest uppercase rounded-xl transition-all duration-300">
                      Close
                    </button>
                  </div>
                </form>
              )}

              <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { icon: Phone, label: 'Agent Phone', value: '+91 98765 43210' },
                  { icon: Mail,  label: 'Agent Email', value: 'sales@akhgroup.com' },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="bg-white p-4 rounded-xl border border-[#e8d0b8] flex items-center gap-3">
                    <div className="bg-red-50 p-2 rounded-lg">
                      <Icon className="text-[#8B1A1A]" size={17} />
                    </div>
                    <div>
                      <div className="text-xs text-[#8B6060] uppercase tracking-wider font-semibold">{label}</div>
                      <div className="text-[#1a0505] text-sm font-bold">{value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
