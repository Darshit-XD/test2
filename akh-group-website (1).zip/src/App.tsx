import { useState, useEffect, useRef } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Properties from './components/Properties';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import logoImg      from "@assets/IMG-20260215-WA0002_cream.jpg";
import logoWhiteImg from "@assets/IMG-20260215-WA0002_white.jpg";

function App() {
  const [loading, setLoading]     = useState(true);
  const [isMobile, setIsMobile]   = useState(false);
  const [cursorPos, setCursorPos] = useState({ x: -200, y: -200 });
  const [dotPos, setDotPos]       = useState({ x: -200, y: -200 });
  const [ringPos, setRingPos]     = useState({ x: -200, y: -200 });
  const ringRef = useRef({ x: -200, y: -200 });
  const rafRef  = useRef<number>(0);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 3400);

    const checkMobile = () =>
      setIsMobile(window.innerWidth < 768 || 'ontouchstart' in window);
    checkMobile();
    window.addEventListener('resize', checkMobile);

    const onMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
      setTimeout(() => setDotPos({ x: e.clientX, y: e.clientY }), 35);
    };
    window.addEventListener('mousemove', onMove);

    const animateRing = () => {
      const tx = isMobile ? window.innerWidth  / 2 : cursorPos.x;
      const ty = isMobile ? window.innerHeight / 2 : cursorPos.y;
      ringRef.current.x += (tx - ringRef.current.x) * 0.09;
      ringRef.current.y += (ty - ringRef.current.y) * 0.09;
      setRingPos({ ...ringRef.current });
      rafRef.current = requestAnimationFrame(animateRing);
    };
    rafRef.current = requestAnimationFrame(animateRing);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('resize', checkMobile);
      cancelAnimationFrame(rafRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isMobile, cursorPos.x, cursorPos.y]);

  const cx = isMobile ? (typeof window !== 'undefined' ? window.innerWidth  / 2 : 196) : cursorPos.x;
  const cy = isMobile ? (typeof window !== 'undefined' ? window.innerHeight / 2 : 311) : cursorPos.y;
  const dx = isMobile ? cx : dotPos.x;
  const dy = isMobile ? cy : dotPos.y;

  return (
    <div className="min-h-screen bg-[#fdf8f0] overflow-x-hidden">

      {/* ── LOADING SCREEN ─────────────────────── */}
      {loading && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center animate-slide-up"
          style={{
            background: 'radial-gradient(ellipse at 50% 48%, #ffffff 0%, #ffffff 48%, #faf4ec 72%, #f2e6d4 100%)',
          }}
        >
          {/* Top + bottom accent stripes */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-[#8B1A1A] via-[#c9943c] to-[#8B1A1A]" />
          <div className="absolute bottom-0 inset-x-0 h-1 bg-gradient-to-r from-[#8B1A1A] via-[#c9943c] to-[#8B1A1A]" />

          <div className="text-center animate-logo-in px-8 relative z-10">
            {/* Logo — white bg, no border, blends directly into white cutscene */}
            <div className="mb-8 inline-block animate-float">
              <img src={logoWhiteImg} alt="AKH GROUP" className="w-36 h-auto block" />
            </div>

            <div className="flex items-baseline justify-center gap-2 mb-2">
              <span className="text-5xl font-serif font-bold text-[#8B1A1A] tracking-tight">AKH</span>
              <span className="text-5xl font-serif font-semibold text-[#1a0505] tracking-widest">GROUP</span>
            </div>
            <p className="text-[#c9943c] text-xs tracking-[0.5em] uppercase font-medium mb-8">
              Premium Real Estate · Noida
            </p>

            {/* Progress bar */}
            <div className="h-1.5 w-60 bg-[#e8d4c0] rounded-full mx-auto overflow-hidden">
              <div
                className="h-full rounded-full animate-[loadingBar_3s_ease-in-out_forwards]"
                style={{ background: 'linear-gradient(to right, #8B1A1A, #c9943c)' }}
              />
            </div>
          </div>
        </div>
      )}

      {/* ── CURSOR ─────────────────────────────── */}
      <div
        className="custom-cursor"
        style={{ left: cx, top: cy, transform: 'translate(-50%, -50%)', position: 'fixed', pointerEvents: 'none', zIndex: 9999 }}
      />
      <div
        className="custom-cursor-dot"
        style={{ left: dx, top: dy, transform: 'translate(-50%, -50%)', position: 'fixed', pointerEvents: 'none', zIndex: 9999 }}
      />
      <div
        className="cursor-ring"
        style={{ left: ringPos.x, top: ringPos.y, position: 'fixed', pointerEvents: 'none', zIndex: 9998 }}
      />

      <Navbar />
      <Hero />
      <Properties />
      <About />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
