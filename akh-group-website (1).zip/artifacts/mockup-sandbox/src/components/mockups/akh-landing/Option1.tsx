import React from 'react';
import { MapPin, Phone, Mail, Instagram, Facebook, Twitter, ArrowRight, CheckCircle2 } from 'lucide-react';

export function Option1() {
  return (
    <div className="min-h-screen bg-[#fdfbf7] text-stone-900 font-sans selection:bg-[#991b1b] selection:text-white overflow-x-hidden">
      {/* Import Playfair Display */}
      <style dangerouslySetInnerHTML={{__html: `
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&display=swap');
      `}} />

      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-[#fdfbf7]/90 backdrop-blur-md border-b border-stone-200/50 transition-all duration-300 py-4 px-6 md:px-12 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#991b1b] text-white flex items-center justify-center font-['Playfair_Display'] font-bold text-xl rounded-sm">A</div>
          <span className="font-['Playfair_Display'] font-semibold tracking-widest text-lg uppercase">AKH Group</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium tracking-wide text-stone-600">
          <a href="#projects" className="hover:text-[#991b1b] transition-colors">Projects</a>
          <a href="#about" className="hover:text-[#991b1b] transition-colors">Heritage</a>
          <a href="#contact" className="hover:text-[#991b1b] transition-colors">Contact</a>
        </div>
        <button className="hidden md:flex px-6 py-2.5 bg-stone-900 text-[#fdfbf7] text-sm tracking-widest uppercase hover:bg-[#991b1b] transition-colors duration-500 rounded-sm">
          Enquire
        </button>
        <button className="md:hidden text-stone-900">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round"/>
          </svg>
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6 md:px-12 lg:px-24 flex flex-col md:flex-row items-center gap-16 min-h-[90vh]">
        <div className="w-full md:w-1/2 z-10">
          <div className="inline-flex items-center gap-3 mb-6">
            <span className="w-12 h-[1px] bg-[#991b1b]"></span>
            <span className="text-[#991b1b] uppercase tracking-[0.2em] text-xs font-semibold">Premium Real Estate</span>
          </div>
          <h1 className="font-['Playfair_Display'] text-5xl md:text-7xl leading-[1.1] mb-8 text-stone-900">
            Crafting <br className="hidden md:block"/>
            <span className="italic text-stone-500">timeless</span> spaces.
          </h1>
          <p className="text-stone-600 text-lg md:text-xl leading-relaxed mb-10 max-w-md font-light">
            Defining luxury living in Noida with architectural excellence and uncompromising quality for over a decade.
          </p>
          <div className="flex flex-col sm:flex-row gap-6">
            <a href="#projects" className="inline-flex justify-center items-center gap-3 px-8 py-4 bg-[#991b1b] text-white hover:bg-stone-900 transition-colors duration-500 uppercase tracking-widest text-sm rounded-sm group">
              View Projects
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#contact" className="inline-flex justify-center items-center px-8 py-4 border border-stone-300 text-stone-800 hover:border-[#991b1b] hover:text-[#991b1b] transition-colors duration-500 uppercase tracking-widest text-sm rounded-sm">
              Contact Sales
            </a>
          </div>
        </div>
        <div className="w-full md:w-1/2 relative h-[500px] md:h-[700px]">
          <div className="absolute inset-0 bg-stone-200 translate-x-4 translate-y-4 md:translate-x-8 md:translate-y-8 rounded-sm"></div>
          <img 
            src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
            alt="Luxury modern home exterior" 
            className="absolute inset-0 w-full h-full object-cover rounded-sm shadow-xl z-10"
          />
        </div>
      </section>

      {/* Stats Section */}
      <section id="about" className="py-20 md:py-32 bg-stone-100 border-y border-stone-200">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 divide-y md:divide-y-0 md:divide-x divide-stone-300">
          <div className="flex flex-col items-center text-center pt-8 md:pt-0">
            <span className="font-['Playfair_Display'] text-6xl md:text-7xl text-[#991b1b] mb-4">15+</span>
            <span className="uppercase tracking-[0.2em] text-sm text-stone-500 font-semibold">Years of Legacy</span>
          </div>
          <div className="flex flex-col items-center text-center pt-8 md:pt-0">
            <span className="font-['Playfair_Display'] text-6xl md:text-7xl text-[#991b1b] mb-4">5k+</span>
            <span className="uppercase tracking-[0.2em] text-sm text-stone-500 font-semibold">Happy Families</span>
          </div>
          <div className="flex flex-col items-center text-center pt-8 md:pt-0">
            <span className="font-['Playfair_Display'] text-6xl md:text-7xl text-[#991b1b] mb-4">10+</span>
            <span className="uppercase tracking-[0.2em] text-sm text-stone-500 font-semibold">Signature Projects</span>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 md:py-40 px-6 md:px-12 lg:px-24 max-w-[1400px] mx-auto">
        <div className="text-center mb-20">
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl mb-6 text-stone-900">Our Portfolio</h2>
          <div className="w-24 h-[1px] bg-[#991b1b] mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-16">
          {/* Project 1 */}
          <div className="group cursor-pointer">
            <div className="relative h-[450px] mb-8 overflow-hidden rounded-sm">
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors duration-700 z-10"></div>
              <img 
                src="https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Royal Apartment" 
                className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000"
              />
            </div>
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-['Playfair_Display'] text-2xl md:text-3xl text-stone-900">Royal Apartment</h3>
              <span className="text-[#991b1b] font-medium tracking-wide">₹85L+</span>
            </div>
            <p className="flex items-center text-stone-500 text-sm tracking-wide uppercase mb-4">
              <MapPin className="w-4 h-4 mr-1.5" /> Noida, India
            </p>
            <div className="h-[1px] w-full bg-stone-200 group-hover:bg-[#991b1b] transition-colors duration-500"></div>
          </div>

          {/* Project 2 */}
          <div className="group cursor-pointer md:-translate-y-12">
            <div className="relative h-[450px] mb-8 overflow-hidden rounded-sm">
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors duration-700 z-10"></div>
              <img 
                src="https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Upwan Residence" 
                className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000"
              />
            </div>
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-['Playfair_Display'] text-2xl md:text-3xl text-stone-900">Upwan Residence</h3>
              <span className="text-[#991b1b] font-medium tracking-wide">₹65L+</span>
            </div>
            <p className="flex items-center text-stone-500 text-sm tracking-wide uppercase mb-4">
              <MapPin className="w-4 h-4 mr-1.5" /> Noida, India
            </p>
            <div className="h-[1px] w-full bg-stone-200 group-hover:bg-[#991b1b] transition-colors duration-500"></div>
          </div>

          {/* Project 3 */}
          <div className="group cursor-pointer">
            <div className="relative h-[450px] mb-8 overflow-hidden rounded-sm">
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors duration-700 z-10"></div>
              <img 
                src="https://images.pexels.com/photos/208736/pexels-photo-208736.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Parth Square" 
                className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-1000"
              />
            </div>
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-['Playfair_Display'] text-2xl md:text-3xl text-stone-900">Parth Square</h3>
              <span className="text-[#991b1b] font-medium tracking-wide">₹55L+</span>
            </div>
            <p className="flex items-center text-stone-500 text-sm tracking-wide uppercase mb-4">
              <MapPin className="w-4 h-4 mr-1.5" /> Noida, India
            </p>
            <div className="h-[1px] w-full bg-stone-200 group-hover:bg-[#991b1b] transition-colors duration-500"></div>
          </div>
        </div>
      </section>

      {/* About Split Section */}
      <section className="py-24 bg-[#f4ebd8]/30">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1 relative">
            <div className="absolute -inset-4 border border-stone-300 rounded-sm"></div>
            <img 
              src="https://images.pexels.com/photos/3791558/pexels-photo-3791558.jpeg?auto=compress&cs=tinysrgb&w=1200" 
              alt="AKH Group architecture" 
              className="w-full h-[600px] object-cover rounded-sm"
            />
          </div>
          <div className="order-1 md:order-2">
            <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl mb-8 text-stone-900 leading-tight">
              A commitment to <br/><span className="italic text-stone-500">unparalleled</span> living.
            </h2>
            <p className="text-stone-600 mb-8 leading-relaxed font-light text-lg">
              At AKH Group, we believe a home is more than an address. It is a sanctuary. For over 15 years, our developments have set the benchmark for luxury real estate in India, blending classic aesthetics with modern functionality.
            </p>
            <ul className="space-y-4 mb-10 text-stone-700">
              <li className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#991b1b]" />
                <span className="tracking-wide">RERA registered properties</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#991b1b]" />
                <span className="tracking-wide">Premium locations across Noida</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#991b1b]" />
                <span className="tracking-wide">Uncompromised build quality</span>
              </li>
            </ul>
            <button className="text-[#991b1b] border-b border-[#991b1b] pb-1 uppercase tracking-widest text-sm font-semibold hover:text-stone-900 hover:border-stone-900 transition-colors">
              Read our story
            </button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 md:py-32 px-6 md:px-12">
        <div className="max-w-4xl mx-auto text-center border border-stone-200 p-12 md:p-24 bg-white shadow-sm rounded-sm">
          <h2 className="font-['Playfair_Display'] text-3xl md:text-5xl mb-6 text-stone-900">Experience the Extraordinary</h2>
          <p className="text-stone-500 mb-12 max-w-xl mx-auto font-light">Connect with our luxury real estate advisors to find your perfect residence.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 text-left divide-y md:divide-y-0 md:divide-x divide-stone-100">
            <div className="flex flex-col items-center text-center pt-6 md:pt-0">
              <Phone className="w-6 h-6 text-[#991b1b] mb-4" />
              <span className="text-sm uppercase tracking-widest text-stone-400 mb-2">Call Us</span>
              <a href="tel:+919876543210" className="text-stone-900 font-medium">+91 98765 43210</a>
            </div>
            <div className="flex flex-col items-center text-center pt-6 md:pt-0">
              <Mail className="w-6 h-6 text-[#991b1b] mb-4" />
              <span className="text-sm uppercase tracking-widest text-stone-400 mb-2">Email</span>
              <a href="mailto:sales@akhgroup.com" className="text-stone-900 font-medium">sales@akhgroup.com</a>
            </div>
            <div className="flex flex-col items-center text-center pt-6 md:pt-0">
              <MapPin className="w-6 h-6 text-[#991b1b] mb-4" />
              <span className="text-sm uppercase tracking-widest text-stone-400 mb-2">Visit</span>
              <span className="text-stone-900 font-medium">Noida, UP, India</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-900 text-stone-400 py-16 px-6 md:px-12">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-6 text-white">
              <div className="w-8 h-8 bg-[#991b1b] flex items-center justify-center font-['Playfair_Display'] font-bold text-xl rounded-sm">A</div>
              <span className="font-['Playfair_Display'] font-semibold tracking-widest text-lg uppercase">AKH Group</span>
            </div>
            <p className="max-w-sm mb-6 font-light text-sm leading-relaxed">
              Curating exceptional living spaces for the discerning few. Building legacies across Noida, India.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full border border-stone-700 flex items-center justify-center hover:bg-[#991b1b] hover:text-white hover:border-[#991b1b] transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-stone-700 flex items-center justify-center hover:bg-[#991b1b] hover:text-white hover:border-[#991b1b] transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-stone-700 flex items-center justify-center hover:bg-[#991b1b] hover:text-white hover:border-[#991b1b] transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-white uppercase tracking-widest text-sm mb-6 font-semibold">Properties</h4>
            <ul className="space-y-4 text-sm font-light">
              <li><a href="#" className="hover:text-white transition-colors">Royal Apartment</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Upwan Residence</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Parth Square</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white uppercase tracking-widest text-sm mb-6 font-semibold">Legal</h4>
            <ul className="space-y-4 text-sm font-light">
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li className="mt-6 pt-6 border-t border-stone-800 flex items-center gap-2 text-white">
                <CheckCircle2 className="w-4 h-4 text-[#991b1b]" />
                <span className="text-xs uppercase tracking-widest font-semibold">RERA Registered</span>
              </li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto border-t border-stone-800 pt-8 text-xs text-stone-500 uppercase tracking-widest text-center md:text-left flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} AKH Group. All rights reserved.</p>
          <p className="mt-4 md:mt-0">Crafted with precision.</p>
        </div>
      </footer>
    </div>
  );
}
