import React from "react";
import { 
  Building2, 
  MapPin, 
  Phone, 
  Mail, 
  ArrowRight, 
  CheckCircle2, 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Menu
} from "lucide-react";

export function Option2() {
  return (
    <div className="min-h-screen bg-white text-black font-sans selection:bg-red-800 selection:text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 mix-blend-difference text-white px-6 py-6 flex justify-between items-center transition-all duration-300">
        <div className="text-2xl font-black tracking-tighter uppercase">
          AKH<span className="text-[#991b1b]">GROUP</span>
        </div>
        
        {/* Desktop Nav */}
        <div className="hidden md:flex gap-8 text-sm font-bold tracking-widest uppercase">
          <a href="#projects" className="hover:text-[#991b1b] transition-colors">Projects</a>
          <a href="#about" className="hover:text-[#991b1b] transition-colors">About</a>
          <a href="#contact" className="hover:text-[#991b1b] transition-colors">Contact</a>
        </div>

        {/* Mobile Menu Icon */}
        <button className="md:hidden text-white">
          <Menu className="w-6 h-6" />
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen w-full flex items-center bg-black">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1920&q=80" 
            alt="Modern Architecture" 
            className="w-full h-full object-cover opacity-50 grayscale"
          />
        </div>
        
        <div className="relative z-10 w-full px-6 md:px-16 lg:px-24">
          <div className="max-w-5xl">
            <h1 className="text-5xl md:text-8xl lg:text-9xl font-black text-white leading-[0.9] tracking-tighter uppercase mb-8">
              Define <br/>
              Your <span className="text-[#991b1b] italic font-serif">Legacy</span>
            </h1>
            <p className="text-gray-300 text-lg md:text-2xl max-w-2xl font-light mb-12">
              Premium real estate developer in Noida, India. Shaping skylines and delivering exceptional living experiences.
            </p>
            <a 
              href="#projects" 
              className="inline-flex items-center gap-4 bg-[#991b1b] text-white px-8 py-5 text-sm md:text-base font-bold tracking-widest uppercase hover:bg-white hover:text-black transition-colors duration-300 group"
            >
              Explore Projects
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 md:py-32 px-6 md:px-16 lg:px-24 bg-white">
        <div className="mb-16 md:mb-24 flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div>
            <h2 className="text-[#991b1b] text-sm font-bold tracking-widest uppercase mb-4 flex items-center gap-2">
              <span className="w-12 h-[2px] bg-[#991b1b]"></span> Our Portfolio
            </h2>
            <h3 className="text-4xl md:text-6xl font-black uppercase tracking-tighter">Featured Projects</h3>
          </div>
          <a href="#" className="hidden md:inline-flex items-center gap-2 text-sm font-bold tracking-widest uppercase hover:text-[#991b1b] transition-colors border-b-2 border-black pb-1 hover:border-[#991b1b]">
            View All Properties <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
          {/* Project 1 */}
          <div className="group cursor-pointer">
            <div className="relative overflow-hidden aspect-[4/5] mb-6 bg-gray-100">
              <img 
                src="https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800&q=80" 
                alt="Royal Apartment" 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
              />
              <div className="absolute top-4 left-4 bg-black text-white px-3 py-1 text-xs font-bold tracking-wider uppercase">
                Premium
              </div>
            </div>
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-2xl font-bold uppercase mb-2">Royal Apartment</h4>
                <p className="text-gray-500 flex items-center gap-1 text-sm"><MapPin className="w-4 h-4" /> Noida, UP</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Starting from</p>
                <p className="text-xl font-bold text-[#991b1b]">₹85L+</p>
              </div>
            </div>
          </div>

          {/* Project 2 */}
          <div className="group cursor-pointer lg:mt-16">
            <div className="relative overflow-hidden aspect-[4/5] mb-6 bg-gray-100">
              <img 
                src="https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg?auto=compress&cs=tinysrgb&w=800&q=80" 
                alt="Upwan Residence" 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
              />
              <div className="absolute top-4 left-4 bg-black text-white px-3 py-1 text-xs font-bold tracking-wider uppercase">
                Luxury
              </div>
            </div>
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-2xl font-bold uppercase mb-2">Upwan Residence</h4>
                <p className="text-gray-500 flex items-center gap-1 text-sm"><MapPin className="w-4 h-4" /> Noida, UP</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Starting from</p>
                <p className="text-xl font-bold text-[#991b1b]">₹65L+</p>
              </div>
            </div>
          </div>

          {/* Project 3 */}
          <div className="group cursor-pointer">
            <div className="relative overflow-hidden aspect-[4/5] mb-6 bg-gray-100">
              <img 
                src="https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg?auto=compress&cs=tinysrgb&w=800&q=80" 
                alt="Parth Square" 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
              />
              <div className="absolute top-4 left-4 bg-black text-white px-3 py-1 text-xs font-bold tracking-wider uppercase">
                Modern
              </div>
            </div>
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-2xl font-bold uppercase mb-2">Parth Square</h4>
                <p className="text-gray-500 flex items-center gap-1 text-sm"><MapPin className="w-4 h-4" /> Noida, UP</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Starting from</p>
                <p className="text-xl font-bold text-[#991b1b]">₹55L+</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="bg-black text-white py-24 md:py-32 px-6 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-[#991b1b] text-sm font-bold tracking-widest uppercase mb-4 flex items-center gap-2">
              <span className="w-12 h-[2px] bg-[#991b1b]"></span> The AKH Legacy
            </h2>
            <h3 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-8">
              Building Trust <br/><span className="text-gray-500">Since 2008.</span>
            </h3>
            <p className="text-gray-400 text-lg font-light mb-12 max-w-lg">
              We don't just build apartments; we craft homes that stand the test of time. With a relentless focus on quality, transparency, and timely delivery, AKH Group has become synonymous with excellence in Noida's real estate landscape.
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <div className="text-4xl md:text-5xl font-black text-[#991b1b] mb-2">15+</div>
                <div className="text-sm text-gray-400 uppercase tracking-wider font-bold">Years Experience</div>
              </div>
              <div>
                <div className="text-4xl md:text-5xl font-black text-[#991b1b] mb-2">5K+</div>
                <div className="text-sm text-gray-400 uppercase tracking-wider font-bold">Happy Families</div>
              </div>
              <div>
                <div className="text-4xl md:text-5xl font-black text-[#991b1b] mb-2">10+</div>
                <div className="text-sm text-gray-400 uppercase tracking-wider font-bold">Projects Delivered</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-[#991b1b] translate-x-4 translate-y-4"></div>
            <img 
              src="https://images.pexels.com/photos/323772/pexels-photo-323772.jpeg?auto=compress&cs=tinysrgb&w=800&q=80" 
              alt="AKH Group Building" 
              className="relative z-10 w-full aspect-square object-cover grayscale border border-white/20"
            />
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 md:py-32 px-6 md:px-16 lg:px-24 bg-gray-50">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-16">
          <div className="lg:col-span-2">
            <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-6">Let's Talk.</h2>
            <p className="text-gray-600 mb-12">Ready to find your dream home? Reach out to our team of experts today.</p>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-black text-white flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-gray-500 mb-1">Call Us</h4>
                  <p className="text-xl font-bold">+91 98765 43210</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-black text-white flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-gray-500 mb-1">Email Us</h4>
                  <p className="text-xl font-bold">sales@akhgroup.com</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[#991b1b] text-white flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-[#991b1b] mb-1">Visit Us</h4>
                  <p className="text-lg font-bold">Noida, Uttar Pradesh, India</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-3 bg-white p-8 md:p-12 shadow-2xl">
            <h3 className="text-2xl font-bold uppercase mb-8">Inquire Now</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">First Name</label>
                  <input type="text" className="w-full border-b-2 border-gray-200 py-3 focus:outline-none focus:border-black transition-colors" placeholder="John" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">Last Name</label>
                  <input type="text" className="w-full border-b-2 border-gray-200 py-3 focus:outline-none focus:border-black transition-colors" placeholder="Doe" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">Email</label>
                  <input type="email" className="w-full border-b-2 border-gray-200 py-3 focus:outline-none focus:border-black transition-colors" placeholder="john@example.com" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">Phone</label>
                  <input type="tel" className="w-full border-b-2 border-gray-200 py-3 focus:outline-none focus:border-black transition-colors" placeholder="+91" />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">Interested In</label>
                <select className="w-full border-b-2 border-gray-200 py-3 focus:outline-none focus:border-black transition-colors bg-transparent">
                  <option>Royal Apartment</option>
                  <option>Upwan Residence</option>
                  <option>Parth Square</option>
                  <option>Other</option>
                </select>
              </div>
              
              <button type="button" className="w-full bg-black text-white py-5 font-bold uppercase tracking-widest hover:bg-[#991b1b] transition-colors mt-8">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white pt-20 pb-10 px-6 md:px-16 lg:px-24 border-t border-white/10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="lg:col-span-2">
            <div className="text-3xl font-black tracking-tighter uppercase mb-6">
              AKH<span className="text-[#991b1b]">GROUP</span>
            </div>
            <p className="text-gray-400 font-light max-w-sm mb-8">
              Defining modern living through exceptional real estate projects in Noida.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 border border-gray-800 flex items-center justify-center hover:bg-[#991b1b] hover:border-[#991b1b] transition-colors rounded-full">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 border border-gray-800 flex items-center justify-center hover:bg-[#991b1b] hover:border-[#991b1b] transition-colors rounded-full">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 border border-gray-800 flex items-center justify-center hover:bg-[#991b1b] hover:border-[#991b1b] transition-colors rounded-full">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 border border-gray-800 flex items-center justify-center hover:bg-[#991b1b] hover:border-[#991b1b] transition-colors rounded-full">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-gray-500">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Home</a></li>
              <li><a href="#projects" className="text-gray-400 hover:text-white transition-colors">Projects</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest mb-6 text-gray-500">Legal</h4>
            <ul className="space-y-4 mb-8">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
            </ul>
            <div className="flex items-center gap-2 border border-white/20 px-4 py-2 inline-flex bg-white/5">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <span className="text-xs font-bold tracking-wider uppercase text-gray-300">RERA Registered</span>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-600 font-bold uppercase tracking-widest">
          <p>&copy; {new Date().getFullYear()} AKH Group. All rights reserved.</p>
          <p>Designed with precision.</p>
        </div>
      </footer>
    </div>
  );
}
