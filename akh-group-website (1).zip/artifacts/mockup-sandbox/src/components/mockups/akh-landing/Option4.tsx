import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  Phone, 
  Mail, 
  ArrowRight, 
  Menu, 
  X,
  CheckCircle2,
  Home,
  Users,
  Award,
  Facebook,
  Twitter,
  Instagram,
  Linkedin
} from 'lucide-react';

export function Option4() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const projects = [
    {
      id: 1,
      name: 'Royal Apartment',
      price: '₹85L+',
      location: 'Sector 150, Noida, India',
      image: 'https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['3 & 4 BHK Premium', 'Club House', 'Swimming Pool']
    },
    {
      id: 2,
      name: 'Upwan Residence',
      price: '₹65L+',
      location: 'Sector 137, Noida, India',
      image: 'https://images.pexels.com/photos/208736/pexels-photo-208736.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['2 & 3 BHK Luxury', 'Park Facing', 'Gymnasium']
    },
    {
      id: 3,
      name: 'Parth Square',
      price: '₹55L+',
      location: 'Sector 75, Noida, India',
      image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['2 BHK Modern', 'Shopping Arena', 'Kids Play Area']
    }
  ];

  const stats = [
    { icon: Award, value: '15+', label: 'Years Experience' },
    { icon: Users, value: '5000+', label: 'Happy Families' },
    { icon: Home, value: '10+', label: 'Projects Completed' },
  ];

  return (
    <div className="min-h-screen bg-white font-sans text-slate-800 selection:bg-red-100 selection:text-red-900 overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex-shrink-0 flex items-center gap-2 cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white shadow-lg shadow-red-200">
                <Building2 size={24} strokeWidth={1.5} />
              </div>
              <span className="font-bold text-2xl tracking-tight text-slate-900">AKH GROUP</span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#home" className="text-slate-600 hover:text-red-700 font-medium transition-colors">Home</a>
              <a href="#projects" className="text-slate-600 hover:text-red-700 font-medium transition-colors">Projects</a>
              <a href="#about" className="text-slate-600 hover:text-red-700 font-medium transition-colors">About</a>
              <a href="#contact" className="text-slate-600 hover:text-red-700 font-medium transition-colors">Contact</a>
              <button className="bg-red-700 hover:bg-red-800 text-white px-6 py-2.5 rounded-full font-medium transition-all shadow-md hover:shadow-lg hover:shadow-red-200 active:scale-95">
                Enquire Now
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center">
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-slate-600 hover:text-red-700 focus:outline-none p-2"
              >
                {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-b border-slate-100 absolute w-full shadow-xl">
            <div className="px-4 pt-2 pb-6 space-y-2">
              <a href="#home" className="block px-4 py-3 text-slate-700 hover:bg-red-50 hover:text-red-700 rounded-xl font-medium" onClick={() => setIsMenuOpen(false)}>Home</a>
              <a href="#projects" className="block px-4 py-3 text-slate-700 hover:bg-red-50 hover:text-red-700 rounded-xl font-medium" onClick={() => setIsMenuOpen(false)}>Projects</a>
              <a href="#about" className="block px-4 py-3 text-slate-700 hover:bg-red-50 hover:text-red-700 rounded-xl font-medium" onClick={() => setIsMenuOpen(false)}>About</a>
              <a href="#contact" className="block px-4 py-3 text-slate-700 hover:bg-red-50 hover:text-red-700 rounded-xl font-medium" onClick={() => setIsMenuOpen(false)}>Contact</a>
              <button className="w-full mt-4 bg-red-700 text-white px-4 py-3 rounded-xl font-medium shadow-md">
                Enquire Now
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        {/* Abstract Background Elements */}
        <div className="absolute top-0 right-0 -translate-y-12 translate-x-1/3 w-[800px] h-[800px] bg-red-50 rounded-full blur-3xl opacity-50 pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 translate-y-1/3 -translate-x-1/3 w-[600px] h-[600px] bg-red-100 rounded-full blur-3xl opacity-30 pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-50 text-red-700 font-semibold text-sm mb-6 border border-red-100">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600"></span>
                </span>
                Premium Properties in Noida
              </div>
              <h1 className="text-5xl lg:text-7xl font-extrabold text-slate-900 leading-[1.1] mb-6 tracking-tight">
                Find Your <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 to-red-800">Perfect Home</span>
              </h1>
              <p className="text-lg lg:text-xl text-slate-600 mb-10 leading-relaxed max-w-lg">
                Discover extraordinary living spaces crafted with precision, designed for comfort, and located in the heart of tomorrow.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-red-700 hover:bg-red-800 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all shadow-lg shadow-red-200 flex items-center justify-center gap-2 group active:scale-95">
                  Explore Projects
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="bg-white text-slate-700 border-2 border-slate-200 hover:border-red-200 hover:bg-red-50 px-8 py-4 rounded-full font-semibold text-lg transition-all active:scale-95">
                  Contact Sales
                </button>
              </div>

              {/* Quick Trust Indicators */}
              <div className="mt-12 pt-8 border-t border-slate-100 flex items-center gap-8">
                <div>
                  <div className="text-3xl font-bold text-slate-900">5k+</div>
                  <div className="text-sm text-slate-500 font-medium">Happy Families</div>
                </div>
                <div className="w-px h-12 bg-slate-200"></div>
                <div>
                  <div className="text-3xl font-bold text-slate-900">10+</div>
                  <div className="text-sm text-slate-500 font-medium">Projects Delivered</div>
                </div>
              </div>
            </div>
            
            <div className="relative lg:h-[600px] h-[400px] rounded-[2rem] overflow-hidden shadow-2xl shadow-slate-200/50">
              <img 
                src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1200" 
                alt="Modern Architecture" 
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent"></div>
              
              {/* Floating Card */}
              <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm p-6 rounded-2xl shadow-xl border border-white/20 transform hover:-translate-y-1 transition-transform">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold text-lg text-slate-900">Royal Apartment</h3>
                  <span className="text-red-700 font-bold bg-red-50 px-3 py-1 rounded-full text-sm">₹85L+</span>
                </div>
                <div className="flex items-center text-slate-500 text-sm">
                  <MapPin size={16} className="mr-1" /> Sector 150, Noida
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 bg-slate-50 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-red-700 font-bold tracking-wide uppercase text-sm mb-3">Featured Properties</h2>
            <h3 className="text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight mb-6">Our Latest Projects</h3>
            <p className="text-lg text-slate-600">
              Explore our meticulously designed properties that blend luxury, comfort, and prime locations in Noida.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <div key={project.id} className="bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300 border border-slate-100 group flex flex-col">
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-4 py-1.5 rounded-full font-bold text-slate-900 shadow-sm">
                    {project.price}
                  </div>
                </div>
                <div className="p-8 flex-1 flex flex-col">
                  <h4 className="text-2xl font-bold text-slate-900 mb-2">{project.name}</h4>
                  <div className="flex items-center text-slate-500 mb-6">
                    <MapPin size={18} className="mr-2 text-red-600" />
                    {project.location}
                  </div>
                  
                  <div className="space-y-3 mb-8 flex-1">
                    {project.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center text-slate-600">
                        <CheckCircle2 size={18} className="mr-3 text-red-600 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <button className="w-full py-4 rounded-xl border-2 border-slate-100 text-slate-700 font-semibold hover:border-red-700 hover:bg-red-700 hover:text-white transition-colors duration-300">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="relative h-[600px] rounded-[2rem] overflow-hidden shadow-2xl">
                <img 
                  src="https://images.pexels.com/photos/37347/office-sitting-room-executive-sitting.jpg?auto=compress&cs=tinysrgb&w=1200" 
                  alt="AKH Group Office" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-red-900/10 mix-blend-multiply"></div>
              </div>
              
              {/* Floating Stat */}
              <div className="absolute -bottom-8 -right-8 bg-red-700 text-white p-8 rounded-[2rem] shadow-xl hidden md:block">
                <div className="text-5xl font-extrabold mb-2">15+</div>
                <div className="text-red-100 font-medium text-lg">Years of<br/>Excellence</div>
              </div>
            </div>

            <div>
              <h2 className="text-red-700 font-bold tracking-wide uppercase text-sm mb-3">About AKH Group</h2>
              <h3 className="text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight mb-6 leading-tight">
                Building Dreams,<br/>Delivering Promises
              </h3>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Since our inception, AKH GROUP has been at the forefront of real estate development in India. We don't just build structures; we create communities that foster growth, happiness, and a superior lifestyle.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-8 mb-10">
                {stats.map((stat, idx) => {
                  const Icon = stat.icon;
                  return (
                    <div key={idx} className="flex gap-4">
                      <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center text-red-700 flex-shrink-0">
                        <Icon size={24} />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
                        <div className="text-sm text-slate-500 font-medium">{stat.label}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <button className="inline-flex items-center gap-2 text-red-700 font-semibold hover:text-red-800 transition-colors group">
                Learn more about our journey
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA / Contact Section */}
      <section id="contact" className="py-24 bg-slate-900 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-red-600/20 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-red-900/40 rounded-full blur-[100px] pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-[3rem] p-8 md:p-16">
            <div className="grid lg:grid-cols-2 gap-16">
              <div>
                <h3 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight mb-6">
                  Ready to find your dream home?
                </h3>
                <p className="text-slate-400 text-lg mb-10">
                  Connect with our property experts today. We're here to help you make the best investment for your future.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-center gap-4 text-white">
                    <div className="w-12 h-12 rounded-full bg-red-700/20 flex items-center justify-center text-red-500">
                      <Phone size={20} />
                    </div>
                    <div>
                      <div className="text-sm text-slate-400">Call Us</div>
                      <div className="text-lg font-semibold">+91 98765 43210</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-white">
                    <div className="w-12 h-12 rounded-full bg-red-700/20 flex items-center justify-center text-red-500">
                      <Mail size={20} />
                    </div>
                    <div>
                      <div className="text-sm text-slate-400">Email Us</div>
                      <div className="text-lg font-semibold">sales@akhgroup.com</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-white">
                    <div className="w-12 h-12 rounded-full bg-red-700/20 flex items-center justify-center text-red-500">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <div className="text-sm text-slate-400">Visit Us</div>
                      <div className="text-lg font-semibold">Noida, UP, India</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-[2rem] p-8 shadow-2xl">
                <h4 className="text-2xl font-bold text-slate-900 mb-6">Request a Callback</h4>
                <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-red-600/20 focus:border-red-600 transition-colors"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                    <input 
                      type="tel" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-red-600/20 focus:border-red-600 transition-colors"
                      placeholder="+91"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Interested Project</label>
                    <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-red-600/20 focus:border-red-600 transition-colors bg-white">
                      <option>Royal Apartment</option>
                      <option>Upwan Residence</option>
                      <option>Parth Square</option>
                    </select>
                  </div>
                  <button type="submit" className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-4 rounded-xl transition-colors mt-4 shadow-lg shadow-red-200">
                    Submit Request
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-300 py-16 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2 lg:col-span-1">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 rounded-lg bg-red-700 flex items-center justify-center text-white">
                  <Building2 size={18} />
                </div>
                <span className="font-bold text-xl text-white tracking-tight">AKH GROUP</span>
              </div>
              <p className="text-slate-400 mb-6 leading-relaxed">
                Shaping the skyline of tomorrow with innovation, quality, and trust. Your dream home awaits.
              </p>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900/50">
                <CheckCircle2 size={16} className="text-green-500" />
                <span className="text-xs font-semibold tracking-wider text-slate-300">RERA REGISTERED</span>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6">Quick Links</h4>
              <ul className="space-y-4">
                <li><a href="#home" className="hover:text-red-500 transition-colors">Home</a></li>
                <li><a href="#projects" className="hover:text-red-500 transition-colors">Projects</a></li>
                <li><a href="#about" className="hover:text-red-500 transition-colors">About Us</a></li>
                <li><a href="#contact" className="hover:text-red-500 transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6">Projects</h4>
              <ul className="space-y-4">
                <li><a href="#" className="hover:text-red-500 transition-colors">Royal Apartment</a></li>
                <li><a href="#" className="hover:text-red-500 transition-colors">Upwan Residence</a></li>
                <li><a href="#" className="hover:text-red-500 transition-colors">Parth Square</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6">Connect</h4>
              <div className="flex gap-4 mb-6">
                <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-red-700 hover:text-white transition-colors">
                  <Facebook size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-red-700 hover:text-white transition-colors">
                  <Twitter size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-red-700 hover:text-white transition-colors">
                  <Instagram size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-red-700 hover:text-white transition-colors">
                  <Linkedin size={18} />
                </a>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-slate-800 text-center text-sm text-slate-500 flex flex-col md:flex-row justify-between items-center gap-4">
            <p>&copy; {new Date().getFullYear()} AKH Group. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
