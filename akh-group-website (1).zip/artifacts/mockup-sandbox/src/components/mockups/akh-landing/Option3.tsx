import React, { useEffect, useState } from "react";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Menu, 
  X, 
  ChevronRight, 
  Star, 
  Award, 
  Users, 
  Building,
  Facebook,
  Twitter,
  Instagram,
  Linkedin
} from "lucide-react";

export function Option3() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const projects = [
    {
      name: "Royal Apartment",
      price: "₹85L+",
      location: "Noida, India",
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["3 & 4 BHK", "Club House", "Smart Home"]
    },
    {
      name: "Upwan Residence",
      price: "₹65L+",
      location: "Noida, India",
      image: "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["2 & 3 BHK", "Park Facing", "Gymnasium"]
    },
    {
      name: "Parth Square",
      price: "₹55L+",
      location: "Noida, India",
      image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["2 BHK", "Retail Shops", "Connectivity"]
    }
  ];

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-100 font-sans selection:bg-[#991b1b] selection:text-white">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-[#0f172a]/90 backdrop-blur-md shadow-[0_4px_30px_rgba(0,0,0,0.5)] border-b border-slate-800/50' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-24">
            <div className="flex-shrink-0 flex items-center cursor-pointer group">
              <span className="text-2xl font-serif font-bold tracking-widest text-white group-hover:text-[#d4af37] transition-colors duration-300">
                AKH <span className="text-[#991b1b]">GROUP</span>
              </span>
            </div>
            
            <div className="hidden md:flex space-x-10 items-center">
              {['Home', 'Projects', 'About', 'Contact'].map((item) => (
                <a key={item} href={`#${item.toLowerCase()}`} className="text-sm font-medium tracking-wider text-slate-300 hover:text-[#d4af37] transition-colors duration-300 uppercase">
                  {item}
                </a>
              ))}
              <button className="px-6 py-2.5 bg-gradient-to-r from-[#991b1b] to-[#7f1616] hover:from-[#7f1616] hover:to-[#5c0f0f] text-white text-sm font-medium tracking-wider uppercase rounded shadow-[0_0_15px_rgba(153,27,27,0.4)] transition-all duration-300 hover:shadow-[0_0_25px_rgba(153,27,27,0.6)]">
                Enquire Now
              </button>
            </div>

            <div className="md:hidden flex items-center">
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-slate-300 hover:text-white">
                {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#0f172a] border-b border-slate-800">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {['Home', 'Projects', 'About', 'Contact'].map((item) => (
                <a 
                  key={item} 
                  href={`#${item.toLowerCase()}`} 
                  className="block px-3 py-4 text-base font-medium tracking-wider text-slate-300 hover:text-[#d4af37] uppercase border-b border-slate-800/50"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
              <div className="p-4">
                <button className="w-full px-6 py-3 bg-[#991b1b] text-white text-sm font-medium tracking-wider uppercase rounded shadow-[0_0_15px_rgba(153,27,27,0.4)]">
                  Enquire Now
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0f172a]/80 via-[#0f172a]/60 to-[#0f172a] z-10" />
          <img 
            src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1920" 
            alt="Luxury Real Estate" 
            className="w-full h-full object-cover object-center scale-105 animate-[pulse_20s_ease-in-out_infinite_alternate]"
          />
        </div>
        
        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/10 backdrop-blur-sm mb-8">
            <Star className="w-4 h-4 text-[#d4af37]" fill="#d4af37" />
            <span className="text-xs font-medium tracking-widest text-[#d4af37] uppercase">Premium Indian Real Estate</span>
          </div>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-white leading-tight mb-6 drop-shadow-2xl">
            Experience <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] to-[#fbf5b7]">Luxury</span> <br/>
            Redefined.
          </h1>
          <p className="mt-6 text-lg md:text-xl text-slate-300 max-w-2xl mx-auto font-light leading-relaxed mb-10">
            Crafting architectural masterpieces that blend modern elegance with timeless comfort in the heart of Noida.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <button className="px-8 py-4 bg-gradient-to-r from-[#991b1b] to-[#7f1616] hover:from-[#7f1616] hover:to-[#5c0f0f] text-white text-sm font-medium tracking-widest uppercase rounded shadow-[0_0_20px_rgba(153,27,27,0.5)] transition-all duration-300 hover:shadow-[0_0_30px_rgba(153,27,27,0.8)] flex items-center gap-2 group">
              Explore Projects
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-8 py-4 bg-transparent border border-slate-500 hover:border-[#d4af37] text-white text-sm font-medium tracking-widest uppercase rounded transition-all duration-300 hover:bg-[#d4af37]/10">
              Contact Sales
            </button>
          </div>
        </div>
        
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 animate-bounce">
          <div className="w-8 h-12 rounded-full border-2 border-slate-500 flex items-start justify-center p-2">
            <div className="w-1 h-3 bg-[#d4af37] rounded-full" />
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 relative z-10 bg-[#0f172a]">
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#d4af37]/30 to-transparent" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-xs font-medium tracking-[0.2em] text-[#991b1b] uppercase mb-4">Portfolio</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6">Our Signature Projects</h3>
            <div className="w-24 h-1 bg-gradient-to-r from-[#991b1b] to-[#d4af37] mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {projects.map((project, index) => (
              <div key={index} className="group rounded-xl overflow-hidden bg-[#1e293b] border border-slate-800 hover:border-[#d4af37]/50 transition-all duration-500 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)] relative">
                <div className="relative h-72 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1e293b] via-transparent to-transparent z-10" />
                  <img 
                    src={project.image} 
                    alt={project.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute top-4 right-4 z-20 bg-[#0f172a]/80 backdrop-blur-md px-3 py-1.5 rounded border border-slate-700">
                    <span className="text-sm font-medium text-[#d4af37]">{project.price}</span>
                  </div>
                </div>
                
                <div className="p-8 relative z-20 -mt-6">
                  <h4 className="text-2xl font-serif font-bold text-white mb-2 group-hover:text-[#d4af37] transition-colors">{project.name}</h4>
                  <div className="flex items-center gap-2 text-slate-400 mb-6 text-sm">
                    <MapPin className="w-4 h-4 text-[#991b1b]" />
                    <span>{project.location}</span>
                  </div>
                  
                  <div className="space-y-3 mb-8">
                    {project.features.map((feature, i) => (
                      <div key={i} className="flex items-center gap-3 text-sm text-slate-300">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#d4af37]" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <button className="w-full py-3 border border-slate-700 hover:border-[#991b1b] hover:bg-[#991b1b]/10 text-white text-sm font-medium tracking-wider uppercase rounded transition-all duration-300">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 relative overflow-hidden bg-[#131c31]">
        {/* Glow effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#991b1b]/5 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-xs font-medium tracking-[0.2em] text-[#d4af37] uppercase mb-4">The Legacy</h2>
              <h3 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6 leading-tight">
                Building Dreams <br/>For Over A Decade
              </h3>
              <p className="text-slate-300 mb-8 font-light leading-relaxed text-lg">
                AKH Group has established itself as a premier real estate developer in India, synonymous with trust, quality, and architectural brilliance. We don't just build homes; we craft lifestyles that resonate with elegance and comfort.
              </p>
              
              <div className="grid grid-cols-2 gap-8 mt-12">
                <div className="p-6 rounded-lg bg-[#0f172a] border border-slate-800 shadow-[0_0_20px_rgba(0,0,0,0.3)] hover:border-[#991b1b]/30 transition-colors group">
                  <Award className="w-10 h-10 text-[#d4af37] mb-4 group-hover:scale-110 transition-transform" />
                  <div className="text-3xl font-serif font-bold text-white mb-1">15+</div>
                  <div className="text-sm text-slate-400 uppercase tracking-wider">Years Experience</div>
                </div>
                <div className="p-6 rounded-lg bg-[#0f172a] border border-slate-800 shadow-[0_0_20px_rgba(0,0,0,0.3)] hover:border-[#991b1b]/30 transition-colors group">
                  <Users className="w-10 h-10 text-[#d4af37] mb-4 group-hover:scale-110 transition-transform" />
                  <div className="text-3xl font-serif font-bold text-white mb-1">5000+</div>
                  <div className="text-sm text-slate-400 uppercase tracking-wider">Happy Families</div>
                </div>
                <div className="p-6 rounded-lg bg-[#0f172a] border border-slate-800 shadow-[0_0_20px_rgba(0,0,0,0.3)] hover:border-[#991b1b]/30 transition-colors group">
                  <Building className="w-10 h-10 text-[#d4af37] mb-4 group-hover:scale-110 transition-transform" />
                  <div className="text-3xl font-serif font-bold text-white mb-1">10+</div>
                  <div className="text-sm text-slate-400 uppercase tracking-wider">Luxury Projects</div>
                </div>
                <div className="p-6 rounded-lg bg-[#0f172a] border border-slate-800 shadow-[0_0_20px_rgba(0,0,0,0.3)] hover:border-[#991b1b]/30 transition-colors group">
                  <Star className="w-10 h-10 text-[#d4af37] mb-4 group-hover:scale-110 transition-transform" />
                  <div className="text-3xl font-serif font-bold text-white mb-1">Premium</div>
                  <div className="text-sm text-slate-400 uppercase tracking-wider">Build Quality</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute inset-0 border-2 border-[#d4af37]/30 rounded-xl translate-x-6 translate-y-6" />
              <img 
                src="https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="AKH Group Building" 
                className="relative z-10 rounded-xl shadow-[0_0_40px_rgba(0,0,0,0.5)] w-full h-auto object-cover aspect-[4/5]"
              />
              <div className="absolute -bottom-8 -left-8 z-20 bg-[#0f172a] p-6 rounded-lg border border-[#991b1b]/30 shadow-[0_0_30px_rgba(153,27,27,0.15)]">
                <div className="text-[#d4af37] font-serif italic text-2xl mb-2">"Excellence in every square foot."</div>
                <div className="text-sm text-slate-400 uppercase tracking-widest">— AKH Leadership</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 relative bg-[#0f172a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#1e293b] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col lg:flex-row relative">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#991b1b]/10 rounded-full blur-[80px]" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#d4af37]/5 rounded-full blur-[80px]" />
            
            <div className="p-12 lg:w-1/2 relative z-10">
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-4">Get In Touch</h2>
              <p className="text-slate-400 mb-10 font-light">
                Schedule a site visit or request a callback from our luxury property advisors.
              </p>
              
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#0f172a] flex items-center justify-center border border-slate-700 flex-shrink-0">
                    <Phone className="w-5 h-5 text-[#d4af37]" />
                  </div>
                  <div>
                    <div className="text-sm text-slate-400 uppercase tracking-wider mb-1">Phone</div>
                    <div className="text-lg font-medium text-white">+91 98765 43210</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#0f172a] flex items-center justify-center border border-slate-700 flex-shrink-0">
                    <Mail className="w-5 h-5 text-[#d4af37]" />
                  </div>
                  <div>
                    <div className="text-sm text-slate-400 uppercase tracking-wider mb-1">Email</div>
                    <div className="text-lg font-medium text-white">sales@akhgroup.com</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#0f172a] flex items-center justify-center border border-slate-700 flex-shrink-0">
                    <MapPin className="w-5 h-5 text-[#d4af37]" />
                  </div>
                  <div>
                    <div className="text-sm text-slate-400 uppercase tracking-wider mb-1">Corporate Office</div>
                    <div className="text-lg font-medium text-white leading-relaxed">
                      AKH Tower, Sector 62,<br />Noida, UP, India
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-12 lg:w-1/2 bg-[#131c31] border-l border-slate-800 relative z-10">
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div>
                  <label className="block text-sm text-slate-400 uppercase tracking-wider mb-2">Full Name</label>
                  <input 
                    type="text" 
                    className="w-full bg-[#0f172a] border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-400 uppercase tracking-wider mb-2">Phone Number</label>
                  <input 
                    type="tel" 
                    className="w-full bg-[#0f172a] border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors"
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-400 uppercase tracking-wider mb-2">Project of Interest</label>
                  <select className="w-full bg-[#0f172a] border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors appearance-none">
                    <option>Royal Apartment</option>
                    <option>Upwan Residence</option>
                    <option>Parth Square</option>
                    <option>General Inquiry</option>
                  </select>
                </div>
                <button type="submit" className="w-full py-4 bg-gradient-to-r from-[#991b1b] to-[#7f1616] hover:from-[#7f1616] hover:to-[#5c0f0f] text-white text-sm font-medium tracking-widest uppercase rounded shadow-[0_0_20px_rgba(153,27,27,0.4)] transition-all duration-300 hover:shadow-[0_0_30px_rgba(153,27,27,0.7)]">
                  Submit Details
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0b1121] pt-16 pb-8 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1">
              <span className="text-2xl font-serif font-bold tracking-widest text-white block mb-6">
                AKH <span className="text-[#991b1b]">GROUP</span>
              </span>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">
                Shaping the skyline of Noida with unparalleled luxury and uncompromising quality.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 rounded-full bg-[#1e293b] flex items-center justify-center text-slate-400 hover:text-[#d4af37] hover:bg-slate-800 transition-all">
                  <Facebook className="w-4 h-4" />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-[#1e293b] flex items-center justify-center text-slate-400 hover:text-[#d4af37] hover:bg-slate-800 transition-all">
                  <Twitter className="w-4 h-4" />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-[#1e293b] flex items-center justify-center text-slate-400 hover:text-[#d4af37] hover:bg-slate-800 transition-all">
                  <Instagram className="w-4 h-4" />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-[#1e293b] flex items-center justify-center text-slate-400 hover:text-[#d4af37] hover:bg-slate-800 transition-all">
                  <Linkedin className="w-4 h-4" />
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-medium uppercase tracking-wider mb-6">Quick Links</h4>
              <ul className="space-y-3">
                {['Home', 'About Us', 'Projects', 'Careers', 'Contact'].map((link) => (
                  <li key={link}>
                    <a href="#" className="text-slate-400 hover:text-[#d4af37] text-sm transition-colors">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-medium uppercase tracking-wider mb-6">Projects</h4>
              <ul className="space-y-3">
                {['Royal Apartment', 'Upwan Residence', 'Parth Square', 'Upcoming Projects'].map((link) => (
                  <li key={link}>
                    <a href="#" className="text-slate-400 hover:text-[#d4af37] text-sm transition-colors">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-medium uppercase tracking-wider mb-6">Compliance</h4>
              <div className="bg-[#1e293b] border border-slate-700 p-4 rounded-lg inline-flex flex-col items-center justify-center text-center">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mb-3">
                  <span className="text-[#991b1b] font-bold text-xs">RERA</span>
                </div>
                <div className="text-white text-sm font-medium">UP RERA Registered</div>
                <div className="text-slate-400 text-xs mt-1">Reg No: UPRERAPRJ12345</div>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-500 text-sm">
              &copy; {new Date().getFullYear()} AKH Group. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-slate-500 hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="text-slate-500 hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
