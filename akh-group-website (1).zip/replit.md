# AKH GROUP — Premium Real Estate Website

## Overview
A premium real estate landing page for AKH GROUP featuring three flagship projects (Royal Apartment, Upwan Residence, Parth Square) all in Noida, India. Design: **Luxury Dark** — deep navy (#0f172a) background with gold (#d4af37) and red (#991b1b) accents, 5-star hotel aesthetic.

## Project Architecture
- **Frontend**: React 18 + TypeScript + Vite + Tailwind CSS
- **Type**: Static frontend-only site (no backend)
- **Styling**: Tailwind CSS with custom dark/gold/red luxury theme
- **Icons**: lucide-react

## File Structure
```
src/
  App.tsx                    - Main app + custom cursor (gold ring, red dot, lagging ring)
  main.tsx                   - Entry point
  index.css                  - Tailwind + luxury dark animations & cursor styles
  components/
    Navbar.tsx               - Fixed nav with real logo + gold glow, working scroll buttons
    Hero.tsx                 - Full-screen hero, kenburns bg, gold shimmer heading
    Properties.tsx           - Two-tier browsing: projects → units → PropertyDetails
    PropertyDetails.tsx      - Full modal with gallery, amenities, enquiry form
    About.tsx                - Stats grid, image with quote card
    Contact.tsx              - Split panel contact form with submission feedback
    Footer.tsx               - Footer with logo, social links, RERA badge, contact info
attached_assets/
  IMG-20260215-WA0002...jpg  - AKH GROUP main logo (used in Navbar, Footer, loading screen)
  IMG-20260215-WA0013...jpg  - Royal Apartment logo
  IMG-20260215-WA0012...jpg  - Parth Square logo
  IMG-20260215-WA0001...jpg  - Upwan Residence logo
```

## Design System
- **Background**: `#0f172a` (deep navy)
- **Gold accent**: `#d4af37` (gold — borders, icons, highlights)
- **Red accent**: `#991b1b` (crimson — buttons, badges, CTAs)
- **Card bg**: `#1e293b` with `rounded-3xl` curved borders
- **Font**: System serif for headings, sans-serif for body

## Animations
- Loading screen with logo float + red-to-gold progress bar
- Multi-layer custom cursor: gold ring (28px), red dot (6px), lagging pulse ring (48px RAF)
- Kenburns hero background pan
- Gold shimmer text on hero heading
- Hover: card lift (`-translate-y-1`), border gold glow, image zoom
- Scroll indicator bounce animation

## Navigation — All Buttons Work
Every button uses `scrollIntoView({ behavior: 'smooth' })`:
- Navbar: Home, Projects, About, Contact, Enquire Now
- Hero: Explore Projects → Properties, Contact Sales → Contact
- Footer: all quick links scroll to sections

## Two-Tier Property Browsing
1. **Projects view**: 3 flagship project cards (click "View Units")
2. **Units view**: sub-properties per project (click "View Details")
3. **PropertyDetails modal**: image gallery, amenities, enquiry form

## Contact Details
- Phone: +91 98765 43210
- Email: sales@akhgroup.com
- Address: Sector 62, Noida, UP, India — 201301

## Running
- Development: `npm run dev` (Vite dev server on port 5000)
- Build: `npm run build` (outputs to `dist/`)
- Deployment: Static deployment serving `dist/`
- GitHub Pages: `base: './'` set in vite.config.ts
